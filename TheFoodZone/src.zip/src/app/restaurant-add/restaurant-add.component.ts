import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RestaurantService } from '../service/restaurant.service';
import { TokenInterceptorService } from '../service/token-interceptor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-restaurant-add',
  templateUrl: './restaurant-add.component.html',
  styleUrls: ['./restaurant-add.component.css']
})
export class RestaurantAddComponent {
update: any;
constructor(private fb:FormBuilder,private service:RestaurantService,private route:Router,
  private tokenService:TokenInterceptorService) {}

  role = this.tokenService.getuserEmail();
  userLoggedIn?:string;
  restaurants:any=[];

  addform = this.fb.group({
    restaurantId:['', Validators.required],
    restaurantName: ['',Validators.required],
    restaurantDescription: ['',Validators.required],
    restaurantlocality: ['',Validators.required],
    
  });
  
  addRestaurant(){
    console.log(this.role)
    if(this.role =="admin@gmail.com"){
      if(this.addform.valid){
        this.service.registerRestaurant(this.addform.value).subscribe(
          response=>{
            alert(`restaurant is added successfully` +response);
            this.service.upadated.emit(true);
            this.addform.reset();
            this.route.navigateByUrl("/restaurant-list");
          },
          error=>{
            alert('add all the particulars' + error);
          }  
        )
      }
    }else{
      alert("You are not authorized to add or delete"+Error);
    }
  }
}
