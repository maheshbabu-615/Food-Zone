import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  getLoginStatus: any;
    onFailure: any;
  homePresent: any;
  findCartCount: any;
  loginSuccess() {
      throw new Error('Method not implemented.');
  }

  constructor() { }
}
