import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { RestaurantService } from '../service/restaurant.service';

@Component({
  selector: 'app-add-food',
  templateUrl: './add-food.component.html',
  styleUrls: ['./add-food.component.css']
})
export class AddItemsComponent {
  userLoggedIn?:string;

  restaurantId:any;

  items:any =[]

  constructor(private fb:FormBuilder,private restaurantService:RestaurantService,private route:Router){}
  
  addform:any=this.fb.group({
    "itemId":['',Validators.required],
   "itemName" :['',Validators.required],
   "imageUrl":['',Validators.required],
   "description":['',Validators.required],
  "itemPrice":['',Validators.required],
  "itemRating":['',Validators.required]
})

addItem(){
  if(this.addform.valid){
    this.items.push(this.addform.value);
    this.restaurantService.getId(this.restaurantId);
    this.restaurantService.addItem(this.items,this.restaurantId).subscribe(
      (      response: any)=>{
        alert("items are added successfully");
        this.route.navigateByUrl('/restaurantView');
      },
      (      error: any)=>{
        alert("add all the details");
      }
    )
  }
 
}

view(){
  this.route.navigateByUrl("/viewAdminItem");
}
update(){
  if(this.addform.valid){
    this.restaurantService.getId(this.restaurantId);
    this.restaurantService.updateItem(this.addform.value,this.restaurantId).subscribe(
      (response: any)=>{
        alert("item have been updated");
        // this.route.navigateByUrl('/adminFoodItem');
      },
      (error: any)=>{
        alert("add all the items");
      }
    )
  }
}
}