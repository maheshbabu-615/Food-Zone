// food-list.component.ts

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantService } from '../service/restaurant.service';
import { Restaurant } from '../model/restaurant';

@Component({
  selector: 'app-food-list',
  templateUrl: './food-list.component.html',
  styleUrls: ['./food-list.component.css'],
})
export class FoodListComponent implements OnInit {
  restaurantId: string | null = null;
  foodList: Restaurant[] = [];

  constructor(
    private restaurantService: RestaurantService,
    private route: ActivatedRoute
  ) {}
 
  ngOnInit(): void {
  //   this.route.paramMap.subscribe((params) => {
  //     this.restaurantId = params.get('restaurantId');
  //     if (this.restaurantId) {
  //       this.restaurantService
  //         .getFoodsForRestaurantId(this.restaurantId)
  //         .subscribe((foods: any) => {
  //           console.log('Food List:', foods);
  //           this.foodList = foods;
  //         });
  //     }
  //   });
   }
  }

