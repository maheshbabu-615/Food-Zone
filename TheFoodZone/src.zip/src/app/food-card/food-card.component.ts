// food-card.component.ts
import { Component, Input } from '@angular/core';


@Component({
    selector: 'app-food-card',
    templateUrl: './food-card.component.html',
    styleUrls: ['./food-card.component.css']
})
export class FoodCardComponent {

@Input() foods: any;
restaurants: any;
}
