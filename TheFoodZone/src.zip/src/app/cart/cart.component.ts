// cart.component.ts
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {

  
removeItem(_t17: any) {
throw new Error('Method not implemented.');
}

  cartItems: any[] = [];

  ngOnInit(): void {
    // Initialize cart items (you can fetch from a service)
    this.cartItems = [
      { foodName: 'Burger',       quantity: 0, price: 200, foodImage: 'burger.jpg' },
      { foodName: 'Pizza',        quantity:0, price: 300, foodImage: 'pizza.jpg' },
      { foodName: 'French fries', quantity:0, price: 400, foodImage:'French fries.jpg'},
      { foodName: 'Potato Chips', quantity:0, price: 100, foodImage:'Potato Chips.jpg'}
      // Add more items as needed
    ];
  }


  calculateTotal(): number {
    return this.cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  }
  proceedToCheckout(): void {
    // Implement the logic to proceed to checkout
    console.log('Proceeding to checkout...');
  }
}
