import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantService } from '../service/restaurant.service';
import { Restaurant } from '../model/restaurant';

@Component({
  selector: 'app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.css'],
})
export class RestaurantListComponent implements OnInit {
  restaurants: Restaurant[] = [];
  filteredRestaurants: Restaurant[] = [];

  constructor(
    private restaurantService: RestaurantService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.restaurantService.getRestaurant().subscribe((result) => {
      this.restaurants = result;
      this.route.paramMap.subscribe((params) => {
        const restaurantId = params.get('id');
        this.filterRestaurants(restaurantId);
      });
    });
  }

  private filterRestaurants(restaurantId: string | null): void {
    if (restaurantId) {
      this.restaurantService.getRestaurant(restaurantId).subscribe((restaurant) => {
        this.filteredRestaurants = [restaurant];
      });
    } else {
      this.filteredRestaurants = this.restaurants;
    }
  }
}
