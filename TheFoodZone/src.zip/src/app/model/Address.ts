export class Address {
    houseNo: number;
    city: string;
    street: string;
    postalCode: string;
  
    constructor(houseNo: number, city: string, street: string, postalCode: string) {
      this.houseNo = houseNo;
      this.city = city;
      this.street = street;
      this.postalCode = postalCode;
    }
  }
  