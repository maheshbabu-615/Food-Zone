export type Food ={
    foodId?: string;
    foodName?: string;
    price?: number;
    foodImage?: string;
    foodDescription?: string;
}
