import { Food } from "../model/food";
export type Restaurant= {
price: any;
foodName: any;
foodDescription: any;
locality: any;
  restaurantId?: string;
  restaurantName?: string;
  restaurantDescription?: string;
  restaurantImage?: string;
  location?: string;
  rating?: number;

}
