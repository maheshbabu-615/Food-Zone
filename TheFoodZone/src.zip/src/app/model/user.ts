import { Address } from "../model/Address"
export type user= {
  userEmail?: string;
  password?: string;
  role?: string;
  address?: Address;
}

