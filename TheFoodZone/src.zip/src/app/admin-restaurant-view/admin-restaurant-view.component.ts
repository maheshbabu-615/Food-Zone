import { Component, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RestaurantService } from '../service/restaurant.service';
@Component({
  selector: 'app-admin-restaurant-view',
  templateUrl: './admin-restaurant-view.component.html',
  styleUrls: ['./admin-restaurant-view.component.css']
})
export class AdminRestaurantViewComponent {
  constructor(private service:RestaurantService,private route:Router,private activatedRoute:ActivatedRoute){
  }

  ngOnInit(): void {
    this.service.getAllRestaurants().subscribe(
      (response: any)=>{
        this.restaurants=response;
      
      },
      (error: any)=>{
        alert("error!!!!");
      }
    )
    this.service.upadated.subscribe((x: boolean)=>{
      if(x==true){
        this.ngOnInit();
      }
    })
  }

  getItems(id:number) {
    this.service.getId(id);
    this.route.navigateByUrl('/adminFoodItem');
    }

    @Input('restaurants') restaurants:any = [];

    getLocation(location:any){
      this.getLocation(location);
      this.service.getRestaurantByLocation(location).subscribe(
        (response: Object) => {
          const restaurantArray = response as any[];
          if(location && location !== ''){
            this.restaurants = restaurantArray.filter((restaurant:any) => restaurant.location === location);
          } else {
            this.restaurants = restaurantArray;
            console.log(restaurantArray);
            
          }
        },
       (error: any)=>{
          alert("error!!!!");
        }
      )
    }

    add(){
      this.route.navigateByUrl('/addRestaurant');
    }

    delete(id:any){
      this.service.deleteRestaurant(id).subscribe(
        (response: any)=>{
          alert("restaurant is deleted");
        },
        (error: any)=>{
          alert("delete is not possible !! You are not admin");
        }
      )
      let arr = this.restaurants.filter((res:{restaurantId:any})=>{
        if(res.restaurantId==id){
          return false;
        }
        else{
          return true;
        }
      })
      this.restaurants=arr;
    }
    update(){}
}