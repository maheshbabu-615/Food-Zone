import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RestaurantListComponent } from './restaurant-list/restaurant-list.component';
import { FoodListComponent } from './food-list/food-list.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { RestaurantAddComponent } from './restaurant-add/restaurant-add.component';
import { AddItemsComponent } from './add-food/add-food.component';



const routes: Routes = [
  
  { path: '', component: HomeComponent },
  { path: 'restaurants/:id', component: RestaurantListComponent },
  { path: 'restaurantId/:foods', component: FoodListComponent },
  { path: 'login', component: LoginComponent},
  { path: 'registration', component: RegistrationComponent },
  { path: 'home', component: HomeComponent},
  { path: 'admin', component: AdminComponent},
  { path: 'add-food', component: AddItemsComponent},
  { path: 'restaurant-add', component: RestaurantAddComponent},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
  
})
export class AppRoutingModule { }
